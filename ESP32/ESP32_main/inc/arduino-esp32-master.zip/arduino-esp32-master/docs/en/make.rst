==============
makeEspArduino
==============

The `makeEspArduino <https://github.com/plerup/makeEspArduino>`_ is a generic makefile for any ESP8266/ESP32 Arduino project.
Using it instead of the Arduino IDE makes it easier to do automated and production builds.
