######
SD MMC
######

About
-----

.. note:: This is a work in progress project and this section is still missing. If you want to contribute, please see the `Contributions Guide <../contributing.html>`_.

Example
-------

To get started with SD_MMC, you can try:

SDMMC Test
**********

.. literalinclude:: ../../../libraries/SD_MMC/examples/SDMMC_Test/SDMMC_Test.ino
    :language: arduino


Complete list of `SD MMC examples <https://github.com/espressif/arduino-esp32/tree/master/libraries/SD_MMC/examples>`_.
