# ESP32 USB HID Joystick Example

This program is derived from hid_host_example.ino with the following changes.

* Add support for two gaming joysticks: Logitech Extreme 3D Pro and Thrustmaster T.16000M.
* Add support for Sony Dual Shock 4 game controller.
* Modify the USB mouse output to support a wider variety of devices such as the Kensington trackball with four buttons and a scroll ring.
